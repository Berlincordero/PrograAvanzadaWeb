﻿namespace ProyectoWeb.Models
{
    public class Class1
    {

    }
}
