﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProyectoWeb.Data.Implementations
{
    public class DALGenericoImpl<TEntity> : Interface.IDALGenerico<TEntity> where TEntity : class
    {
        private MediaDashboardContext _schoolContext;

        public DALGenericoImpl(SchoolContext schoolContext)
        {

            _schoolContext = schoolContext;
        }

        public bool Add(TEntity entity)
        {
            try
            {
                _schoolContext.Add(entity);
                return true;

            }
            catch (Exception)
            {

                return false;
            }
        }

        public TEntity Get(int id)
        {

            return _schoolContext.Set<TEntity>().Find(id);
        }

        public IEnumerable<TEntity> GetAll()
        {
            return _schoolContext.Set<TEntity>().ToList();
        }

        public bool Remove(TEntity entity)
        {
            try
            {
                _schoolContext.Set<TEntity>().Attach(entity);
                _schoolContext.Set<TEntity>().Remove(entity);
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public bool Update(TEntity entity)
        {
            try
            {
                _schoolContext.Entry(entity).State = EntityState.Modified;
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}
