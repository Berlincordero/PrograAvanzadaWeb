﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoWeb.Data.Implementations
{
    public class UnidadDeTrabajo : IUnidadDeTrabajo
    {
        public IPersonDAL PersonDAL { get; set; }
        private SchoolContext _SchoolContext;



        public UnidadDeTrabajo(SchoolContext schoolContext, IPersonDAL personDAL)
        {
            _SchoolContext = schoolContext;
            PersonDAL = personDAL;
        }


        public bool Complete()
        {
            try
            {
                _SchoolContext.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public void Dispose()
        {
            _SchoolContext.Dispose();
        }

    }
}