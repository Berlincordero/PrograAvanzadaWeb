﻿namespace ProyectoWeb.Service
{
    public class Class1
    {

    }
}
