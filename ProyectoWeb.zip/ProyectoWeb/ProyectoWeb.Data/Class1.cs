﻿namespace ProyectoWeb.Data
{
    public class Class1
    {

    }
}
